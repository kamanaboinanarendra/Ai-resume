import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { FileText, PlusCircle, FolderGit2, User, LogOut, Menu, X, Sparkles } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useAIChat } from '../context/AIChatContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { setIsOpen, setIsMinimized } = useAIChat();
  const location = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { name: 'Dashboard', path: '/dashboard', icon: FileText },
    { name: 'Create Resume', path: '/templates', icon: PlusCircle },
    { name: 'My Resumes', path: '/my-resumes', icon: FolderGit2 },
    { name: 'Account', path: '/account', icon: User },
  ];

  const isActive = (path) => location.pathname === path;

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-[#E5E7EB] shadow-xs no-print">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <Link to="/dashboard" className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 rounded-xl bg-[#D62828] flex items-center justify-center text-white shadow-sm group-hover:bg-[#A61B1B] transition-colors">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-lg tracking-tight text-[#222222]">AI Resume</span>
              <span className="text-[#D62828] font-bold text-lg tracking-tight">Builder</span>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav aria-label="Main Navigation" className="hidden md:flex items-center gap-1">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const active = isActive(link.path);
              return (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium transition-all ${
                    active
                      ? 'bg-[#FFF7F7] text-[#D62828] font-semibold border border-[#E5E7EB]'
                      : 'text-[#6B7280] hover:text-[#222222] hover:bg-gray-50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${active ? 'text-[#D62828]' : 'text-[#6B7280]'}`} />
                  {link.name}
                </Link>
              );
            })}
          </nav>

          {/* Right Header Actions */}
          <div className="hidden md:flex items-center gap-3">
            {/* AI Assistant Quick Toggle */}
            <button
              onClick={() => {
                setIsOpen(true);
                setIsMinimized(false);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-[#E5E7EB] text-xs font-medium text-[#222222] hover:bg-[#FFF7F7] hover:text-[#D62828] hover:border-[#D62828] transition-colors"
              title="Open AI Chat Assistant"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#D62828]" />
              <span>AI Chat</span>
            </button>

            {/* User Greeting & Logout */}
            <div className="flex items-center gap-2 pl-2 border-l border-[#E5E7EB]">
              <span className="text-xs text-[#6B7280]">
                Hello, <strong className="text-[#222222]">{user?.name?.split(' ')[0] || 'User'}</strong>
              </span>
              <button
                onClick={logout}
                className="p-2 text-[#6B7280] hover:text-[#DC2626] hover:bg-red-50 rounded-lg transition-colors"
                title="Log out"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => {
                setIsOpen(true);
                setIsMinimized(false);
              }}
              className="p-2 text-[#D62828] hover:bg-[#FFF7F7] rounded-lg"
              title="AI Assistant"
            >
              <Sparkles className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#6B7280] hover:text-[#222222] hover:bg-gray-100 rounded-lg"
              aria-label="Toggle Navigation Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-[#E5E7EB] bg-white px-4 pt-2 pb-4 space-y-1 shadow-lg">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const active = isActive(link.path);
            return (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${
                  active
                    ? 'bg-[#FFF7F7] text-[#D62828] font-semibold'
                    : 'text-[#6B7280] hover:bg-gray-50'
                }`}
              >
                <Icon className={`w-5 h-5 ${active ? 'text-[#D62828]' : 'text-[#6B7280]'}`} />
                {link.name}
              </Link>
            );
          })}
          <div className="pt-3 border-t border-[#E5E7EB] flex items-center justify-between">
            <span className="text-xs text-[#6B7280]">{user?.email}</span>
            <button
              onClick={logout}
              className="flex items-center gap-1.5 text-xs text-[#DC2626] font-medium px-3 py-1.5 hover:bg-red-50 rounded"
            >
              <LogOut className="w-3.5 h-3.5" />
              Logout
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
