import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Sparkles, Eye, ArrowRight, Check, X, LayoutTemplate } from 'lucide-react';
import api from '../services/api';
import ResumeRenderer from '../templates/ResumeRenderer';

// Sample demonstration resume data for realistic gallery preview modal
const SAMPLE_PREVIEW_DATA = {
  personal_info: {
    full_name: "Alex Morgan",
    professional_title: "Senior Full Stack & AI Engineer",
    email: "alex.morgan@example.com",
    phone: "+1 (555) 234-5678",
    city_country: "San Francisco, CA",
    linkedin_url: "https://linkedin.com/in/alexmorgan",
    github_url: "https://github.com/alexmorgan",
    portfolio_url: "https://alexmorgan.dev"
  },
  professional_summary: "Results-driven Software Engineer with 5+ years of experience designing scalable distributed web architectures, high-throughput microservices, and integrating generative AI tools. Proven success in modernizing backend latency by 35% and mentoring agile development teams.",
  experience: [
    {
      id: "1",
      job_title: "Senior Full Stack Engineer",
      company: "Nexus Technologies",
      location: "San Francisco, CA",
      employment_type: "Full-time",
      start_date: "2022",
      end_date: "Present",
      currently_working: true,
      responsibilities: "Architected real-time analytics pipeline using FastAPI and PostgreSQL handling 2M+ daily events.\nEngineered responsive component design system in React and Tailwind CSS.",
      achievements: "Reduced server response time by 40% through intelligent query caching and index restructuring."
    },
    {
      id: "2",
      job_title: "Software Engineer",
      company: "Apex Digital Labs",
      location: "Austin, TX",
      employment_type: "Full-time",
      start_date: "2020",
      end_date: "2022",
      currently_working: false,
      responsibilities: "Developed RESTful APIs and integrated third-party payment gateways.\nCollaborated directly with product managers to deliver 12 major sprint deliverables on time.",
      achievements: "Led transition to containerized CI/CD workflow with Docker, eliminating deployment rollbacks."
    }
  ],
  education: [
    {
      id: "1",
      degree: "B.Tech in Computer Science & Engineering",
      institution: "State University of Technology",
      location: "Austin, TX",
      start_date: "2016",
      end_date: "2020",
      gpa: "3.85 / 4.0",
      coursework: "Data Structures, Database Management, Operating Systems, Machine Learning"
    }
  ],
  projects: [
    {
      id: "1",
      name: "CloudScale Monitor",
      technologies: "Python, FastAPI, Redis, Docker",
      github_url: "https://github.com/alexmorgan/cloudscale",
      live_url: "https://cloudscale.demo",
      description: "Distributed infrastructure monitoring dashboard with automated alert triggers and metrics telemetry."
    }
  ],
  skills: [
    { id: "1", category_name: "Languages", skills: ["Python", "JavaScript", "TypeScript", "SQL"] },
    { id: "2", category_name: "Frameworks & Cloud", skills: ["React", "FastAPI", "Node.js", "Docker", "PostgreSQL", "AWS"] }
  ],
  certifications: [
    { id: "1", name: "AWS Certified Solutions Architect", issuer: "Amazon Web Services", issue_date: "2023" }
  ],
  customization: {
    font_family: "Inter",
    primary_color: "#D62828",
    layout_spacing: "normal"
  }
};

export default function TemplateGalleryPage() {
  const navigate = useNavigate();
  const [templates, setTemplates] = useState([]);
  const [categories, setCategories] = useState(["All"]);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [searchQuery, setSearchQuery] = useState("");
  const [loading, setLoading] = useState(true);
  const [previewTemplate, setPreviewTemplate] = useState(null);
  const [creatingResume, setCreatingResume] = useState(false);

  useEffect(() => {
    const fetchTemplates = async () => {
      try {
        const res = await api.get('/templates');
        setTemplates(res.data.templates || []);
        setCategories(res.data.categories || ["All"]);
      } catch (err) {
        console.error('Failed to load templates:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchTemplates();
  }, []);

  const handleUseTemplate = async (templateId) => {
    setCreatingResume(true);
    try {
      const res = await api.post('/resumes', {
        title: "My New Resume",
        template_id: templateId,
        resume_data: {
          ...SAMPLE_PREVIEW_DATA,
          customization: {
            ...SAMPLE_PREVIEW_DATA.customization,
            primary_color: templates.find(t => t.id === templateId)?.thumbnail_accent || '#D62828'
          }
        }
      });
      navigate(`/builder/${res.data.id}`);
    } catch (err) {
      console.error('Failed to create resume:', err);
      alert('Could not initialize resume. Please try again.');
    } finally {
      setCreatingResume(false);
    }
  };

  const filteredTemplates = templates.filter((tmpl) => {
    const matchesCategory =
      selectedCategory === 'All' || tmpl.category === selectedCategory;
    const matchesSearch =
      tmpl.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tmpl.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tmpl.layout_family.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
      {/* Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#FFF7F7] border border-[#E5E7EB] text-[#D62828] text-xs font-semibold uppercase tracking-wider mb-3">
          <Sparkles className="w-3.5 h-3.5" />
          <span>25 High-Impact Layouts</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-[#222222] tracking-tight">
          Select Your Professional Resume Template
        </h1>
        <p className="mt-3 text-sm sm:text-base text-[#6B7280]">
          Choose from 25 real, purpose-engineered templates across 7 layout configurations. Every template formats your real data dynamically and exports to crisp PDF.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-8 bg-white p-3 rounded-2xl border border-[#E5E7EB] shadow-xs">
        {/* Category Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-2 md:pb-0 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                selectedCategory === cat
                  ? 'bg-[#D62828] text-white shadow-xs font-semibold'
                  : 'text-[#6B7280] hover:text-[#222222] hover:bg-[#FFF7F7]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative w-full md:w-72">
          <Search className="w-4 h-4 text-[#6B7280] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search templates or layouts..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-gray-50 border border-[#E5E7EB] rounded-xl focus:outline-none focus:border-[#D62828] focus:bg-white text-[#222222]"
          />
        </div>
      </div>

      {/* Templates Grid */}
      {loading ? (
        <div className="py-24 text-center">
          <div className="w-10 h-10 border-4 border-[#E5E7EB] border-t-[#D62828] rounded-full animate-spin mx-auto mb-3"></div>
          <p className="text-xs text-[#6B7280]">Loading template catalog...</p>
        </div>
      ) : filteredTemplates.length === 0 ? (
        <div className="py-16 text-center bg-white rounded-2xl border border-[#E5E7EB] p-8">
          <LayoutTemplate className="w-12 h-12 text-[#6B7280] mx-auto mb-3 opacity-50" />
          <h3 className="text-base font-semibold text-[#222222]">No templates found</h3>
          <p className="text-xs text-[#6B7280] mt-1">Try adjusting your search or category filter.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTemplates.map((tmpl) => (
            <div
              key={tmpl.id}
              className="group bg-white rounded-2xl border border-[#E5E7EB] hover:border-[#D62828]/40 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col overflow-hidden"
            >
              {/* Realistic Visual Thumbnail Box */}
              <div 
                className="relative h-56 bg-gray-50 border-b border-[#E5E7EB] p-3 flex flex-col justify-start overflow-hidden cursor-pointer"
                onClick={() => setPreviewTemplate(tmpl)}
              >
                {/* Mini mockup rendering corresponding to layout family */}
                <div className="w-full h-full bg-white rounded-lg shadow-sm border border-gray-200/80 p-3 flex flex-col text-[7px] leading-tight select-none pointer-events-none transform group-hover:scale-[1.02] transition-transform duration-300">
                  {/* Top Header Mockup */}
                  {tmpl.layout_family === 'bold-header' ? (
                    <div 
                      className="p-2 text-white rounded mb-2 -mx-1 -mt-1"
                      style={{ backgroundColor: tmpl.thumbnail_accent }}
                    >
                      <div className="font-bold text-[8px] truncate">Alex Morgan</div>
                      <div className="opacity-80 text-[6px]">Software Engineer</div>
                    </div>
                  ) : tmpl.layout_family === 'left-sidebar' ? (
                    <div className="flex gap-2 h-full">
                      <div className="w-1/3 bg-gray-50 p-1 rounded border-r border-gray-100 flex flex-col gap-1">
                        <div className="w-5 h-5 rounded-md text-white font-bold flex items-center justify-center text-[7px]" style={{ backgroundColor: tmpl.thumbnail_accent }}>A</div>
                        <div className="font-bold text-[7px] truncate">Alex M.</div>
                        <div className="h-1 bg-gray-200 rounded w-full"></div>
                        <div className="h-1 bg-gray-200 rounded w-3/4"></div>
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="font-bold text-[7px] text-gray-800">EXPERIENCE</div>
                        <div className="h-1.5 bg-gray-200 rounded w-full"></div>
                        <div className="h-1 bg-gray-100 rounded w-5/6"></div>
                        <div className="h-1 bg-gray-100 rounded w-4/6"></div>
                      </div>
                    </div>
                  ) : tmpl.layout_family === 'modern-split' ? (
                    <div className="space-y-1">
                      <div className="border-b pb-1 flex justify-between items-baseline" style={{ borderColor: tmpl.thumbnail_accent }}>
                        <span className="font-bold text-[8px] text-gray-900">Alex Morgan</span>
                        <span className="text-[6px] text-gray-500">San Francisco, CA</span>
                      </div>
                      <div className="grid grid-cols-12 gap-1.5 pt-0.5">
                        <div className="col-span-8 space-y-1">
                          <div className="font-bold text-[6px]" style={{ color: tmpl.thumbnail_accent }}>EXPERIENCE</div>
                          <div className="h-1 bg-gray-200 rounded w-full"></div>
                          <div className="h-1 bg-gray-100 rounded w-5/6"></div>
                        </div>
                        <div className="col-span-4 border-l pl-1 space-y-1">
                          <div className="font-bold text-[6px]" style={{ color: tmpl.thumbnail_accent }}>SKILLS</div>
                          <div className="h-1 bg-gray-200 rounded w-full"></div>
                          <div className="h-1 bg-gray-100 rounded w-3/4"></div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-1.5">
                      <div className="text-center border-b pb-1">
                        <div className="font-bold text-[9px] text-gray-900">Alex Morgan</div>
                        <div className="text-[6px] text-gray-500">Senior Full Stack Engineer • alex@example.com</div>
                      </div>
                      <div className="space-y-1">
                        <div className="font-bold text-[6px] uppercase" style={{ color: tmpl.thumbnail_accent }}>
                          Professional Experience
                        </div>
                        <div className="h-1.5 bg-gray-200 rounded w-full"></div>
                        <div className="h-1 bg-gray-100 rounded w-11/12"></div>
                        <div className="h-1 bg-gray-100 rounded w-4/5"></div>
                      </div>
                      <div className="space-y-1 pt-1">
                        <div className="font-bold text-[6px] uppercase" style={{ color: tmpl.thumbnail_accent }}>
                          Skills & Tech Stack
                        </div>
                        <div className="h-1 bg-gray-200 rounded w-full"></div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Hover overlay with preview action */}
                <div className="absolute inset-0 bg-[#222222]/40 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center gap-2">
                  <span className="inline-flex items-center gap-1.5 bg-white text-[#222222] font-semibold text-xs px-3.5 py-2 rounded-xl shadow-md transform translate-y-2 group-hover:translate-y-0 transition-transform">
                    <Eye className="w-3.5 h-3.5" />
                    Preview
                  </span>
                </div>
              </div>

              {/* Template Card Details */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <h3 className="font-bold text-sm text-[#222222] group-hover:text-[#D62828] transition-colors truncate">
                      {tmpl.name}
                    </h3>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#FFF7F7] text-[#D62828] border border-[#E5E7EB] uppercase tracking-wider flex-shrink-0">
                      {tmpl.category}
                    </span>
                  </div>
                  <p className="text-xs text-[#6B7280] line-clamp-2 mb-3">
                    {tmpl.description}
                  </p>
                </div>

                <div className="pt-2 border-t border-[#E5E7EB] flex items-center gap-2">
                  <button
                    onClick={() => setPreviewTemplate(tmpl)}
                    className="flex-1 py-2 text-xs font-semibold text-[#222222] hover:text-[#D62828] hover:bg-[#FFF7F7] rounded-xl border border-[#E5E7EB] transition-colors flex items-center justify-center gap-1"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    Preview
                  </button>
                  <button
                    onClick={() => handleUseTemplate(tmpl.id)}
                    disabled={creatingResume}
                    className="flex-1 py-2 text-xs font-semibold bg-[#D62828] hover:bg-[#A61B1B] text-white rounded-xl shadow-xs transition-colors flex items-center justify-center gap-1 disabled:opacity-50"
                  >
                    <span>Use Template</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Fullscreen Realistic Preview Modal */}
      {previewTemplate && (
        <div className="fixed inset-0 z-50 bg-[#222222]/70 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="px-6 py-4 bg-white border-b border-[#E5E7EB] flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-lg font-bold text-[#222222]">{previewTemplate.name}</h2>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#FFF7F7] text-[#D62828] border border-[#E5E7EB] font-semibold">
                    {previewTemplate.category}
                  </span>
                </div>
                <p className="text-xs text-[#6B7280] mt-0.5">{previewTemplate.description}</p>
              </div>

              <div className="flex items-center gap-3">
                <button
                  onClick={() => handleUseTemplate(previewTemplate.id)}
                  disabled={creatingResume}
                  className="px-4 py-2 bg-[#D62828] hover:bg-[#A61B1B] text-white text-xs font-semibold rounded-xl shadow-sm flex items-center gap-1.5 transition-colors"
                >
                  <Check className="w-4 h-4" />
                  <span>Use This Template</span>
                </button>
                <button
                  onClick={() => setPreviewTemplate(null)}
                  className="p-2 text-[#6B7280] hover:text-[#222222] hover:bg-gray-100 rounded-xl"
                  title="Close preview"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Modal Scrollable Resume Content */}
            <div className="flex-1 overflow-y-auto p-6 bg-gray-100 flex justify-center">
              <div className="w-full max-w-[800px] shadow-lg rounded-xl overflow-hidden bg-white">
                <ResumeRenderer 
                  resumeData={{
                    ...SAMPLE_PREVIEW_DATA,
                    customization: {
                      ...SAMPLE_PREVIEW_DATA.customization,
                      primary_color: previewTemplate.thumbnail_accent
                    }
                  }}
                  templateId={previewTemplate.id}
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
