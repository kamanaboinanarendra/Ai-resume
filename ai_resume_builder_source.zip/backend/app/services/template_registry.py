from typing import List, Optional
from app.schemas.template import TemplateInfo

TEMPLATES: List[TemplateInfo] = [
    # 1-5 Professional
    TemplateInfo(
        id="classic-professional",
        name="Classic Professional",
        category="Professional",
        description="Timeless traditional layout with centered header, refined horizontal rules, and balanced serif/sans typography.",
        layout_family="classic-single",
        thumbnail_accent="#1E293B",
        recommended_for="Mid-to-senior corporate professionals, management, and traditional industries."
    ),
    TemplateInfo(
        id="modern-professional",
        name="Modern Professional",
        category="Professional",
        description="Sleek dual-column layout with left emphasis on summary and credentials, and spacious right experience section.",
        layout_family="modern-split",
        thumbnail_accent="#D62828",
        recommended_for="Engineers, consultants, and business analysts seeking a polished contemporary feel."
    ),
    TemplateInfo(
        id="corporate-executive",
        name="Corporate Executive",
        category="Professional",
        description="Authoritative structure featuring a distinguished bold banner header, executive summary spotlight, and milestone metrics.",
        layout_family="bold-header",
        thumbnail_accent="#0F172A",
        recommended_for="Directors, VPs, project managers, and executive leadership."
    ),
    TemplateInfo(
        id="clean-minimalist",
        name="Clean Minimalist",
        category="Professional",
        description="Airy, high-readability design with subtle dividers, generous margins, and distraction-free typography.",
        layout_family="classic-single",
        thumbnail_accent="#475569",
        recommended_for="Professionals who prefer understated sophistication and clarity."
    ),
    TemplateInfo(
        id="elegant-traditional",
        name="Elegant Traditional",
        category="Professional",
        description="Classic Roman typography styling with formal section headings and dignified vertical flow.",
        layout_family="classic-single",
        thumbnail_accent="#78350F",
        recommended_for="Legal, finance, administration, and academia."
    ),

    # 6-10 Technology
    TemplateInfo(
        id="software-developer",
        name="Software Developer",
        category="Technology",
        description="Technical-first layout featuring prominent skills matrices, GitHub/live links, and structured project callouts.",
        layout_family="compact-grid",
        thumbnail_accent="#0284C7",
        recommended_for="Software engineers, mobile app developers, and system programmers."
    ),
    TemplateInfo(
        id="python-developer",
        name="Python Developer",
        category="Technology",
        description="Clean tech layout highlighting backend frameworks, databases, package experience, and architectural contributions.",
        layout_family="compact-grid",
        thumbnail_accent="#0D9488",
        recommended_for="Python, Django, FastAPI, data pipelines, and automation specialists."
    ),
    TemplateInfo(
        id="full-stack-developer",
        name="Full Stack Developer",
        category="Technology",
        description="Dynamic split layout balancing frontend/backend skill sets with end-to-end full stack project demonstrations.",
        layout_family="modern-split",
        thumbnail_accent="#4F46E5",
        recommended_for="Full-stack web engineers and product developers."
    ),
    TemplateInfo(
        id="backend-developer",
        name="Backend Developer",
        category="Technology",
        description="Focused single-column technical hierarchy showcasing APIs, cloud infrastructure, and database design.",
        layout_family="accent-timeline",
        thumbnail_accent="#15803D",
        recommended_for="Backend engineers, cloud architects, and DevOps specialists."
    ),
    TemplateInfo(
        id="data-analyst",
        name="Data Analyst",
        category="Technology",
        description="Data-centric layout emphasizing analytical tools, SQL/Python proficiency, BI dashboards, and business insights.",
        layout_family="compact-grid",
        thumbnail_accent="#D97706",
        recommended_for="Data analysts, business intelligence analysts, and data scientists."
    ),

    # 11-15 Student and Fresher
    TemplateInfo(
        id="college-student",
        name="College Student",
        category="Student and Fresher",
        description="Education-first layout with CGPA emphasis, academic coursework, and campus leadership.",
        layout_family="classic-single",
        thumbnail_accent="#2563EB",
        recommended_for="University students seeking their first professional opportunities."
    ),
    TemplateInfo(
        id="fresher-resume",
        name="Fresher Resume",
        category="Student and Fresher",
        description="Balanced design designed specifically to turn academic projects and technical skills into compelling credentials.",
        layout_family="accent-timeline",
        thumbnail_accent="#7C3AED",
        recommended_for="Recent college graduates and entry-level job seekers."
    ),
    TemplateInfo(
        id="internship-resume",
        name="Internship Resume",
        category="Student and Fresher",
        description="Proactive layout spotlighting hands-on hackathons, relevant coursework, and eager-to-learn skill breadth.",
        layout_family="left-sidebar",
        thumbnail_accent="#D62828",
        recommended_for="Students applying for competitive summer or semester internships."
    ),
    TemplateInfo(
        id="campus-placement",
        name="Campus Placement",
        category="Student and Fresher",
        description="Standardized placement cell format optimized for college drive recruiters with clear academic and extracurricular sections.",
        layout_family="classic-single",
        thumbnail_accent="#334155",
        recommended_for="On-campus university hiring and mass recruitment drives."
    ),
    TemplateInfo(
        id="academic-resume",
        name="Academic Resume",
        category="Student and Fresher",
        description="Comprehensive curriculum vitae layout featuring research projects, papers, conferences, and academic honors.",
        layout_family="classic-single",
        thumbnail_accent="#475569",
        recommended_for="Graduate school applications, research assistantships, and fellowships."
    ),

    # 16-20 Creative
    TemplateInfo(
        id="creative-modern",
        name="Creative Modern",
        category="Creative",
        description="Vibrant contemporary layout with stylish accent blocks, distinctive headers, and portfolio showcase links.",
        layout_family="bold-header",
        thumbnail_accent="#E11D48",
        recommended_for="UI/UX designers, frontend developers, and product designers."
    ),
    TemplateInfo(
        id="bold-header",
        name="Bold Header",
        category="Creative",
        description="Striking top banner in brand crimson with crisp white typography and modern card-style section blocks.",
        layout_family="bold-header",
        thumbnail_accent="#D62828",
        recommended_for="Marketers, creative technologists, and dynamic innovators."
    ),
    TemplateInfo(
        id="modern-two-column",
        name="Modern Two-Column",
        category="Creative",
        description="High-density aesthetic balance between a sleek left identity column and rich right achievement blocks.",
        layout_family="modern-split",
        thumbnail_accent="#9333EA",
        recommended_for="Creative directors, content strategists, and modern tech professionals."
    ),
    TemplateInfo(
        id="elegant-typography",
        name="Elegant Typography",
        category="Creative",
        description="Refined editorial layout prioritizing typographic contrast, pull quotes, and subtle accent lines.",
        layout_family="classic-single",
        thumbnail_accent="#BE123C",
        recommended_for="Writers, communications specialists, and brand managers."
    ),
    TemplateInfo(
        id="accent-sidebar",
        name="Accent Sidebar",
        category="Creative",
        description="Rich shaded left sidebar for key identity, contact URLs, and categorized skill badges.",
        layout_family="left-sidebar",
        thumbnail_accent="#C026D3",
        recommended_for="Designers, full-stack engineers, and digital specialists."
    ),

    # 21-25 ATS-Friendly
    TemplateInfo(
        id="ats-classic",
        name="ATS Classic",
        category="ATS-Friendly",
        description="Optimized single-column parser-friendly layout adhering strictly to standard headings and clean text flow.",
        layout_family="ats-clean",
        thumbnail_accent="#0F172A",
        recommended_for="Automated applicant tracking systems, job boards, and enterprise portals."
    ),
    TemplateInfo(
        id="ats-modern",
        name="ATS Modern",
        category="ATS-Friendly",
        description="Modernized parser-friendly layout with crisp horizontal dividers and machine-readable bullet points.",
        layout_family="ats-clean",
        thumbnail_accent="#1E293B",
        recommended_for="Corporate job applications requiring high ATS keyword extractability."
    ),
    TemplateInfo(
        id="single-column-professional",
        name="Single-Column Professional",
        category="ATS-Friendly",
        description="Strict linear chronological sequence ensuring flawless parsing across Workday, Taleo, and Greenhouse.",
        layout_family="ats-clean",
        thumbnail_accent="#334155",
        recommended_for="Enterprise applications and government or large corporate recruitment."
    ),
    TemplateInfo(
        id="technical-skills-focus",
        name="Technical Skills Focus",
        category="ATS-Friendly",
        description="ATS-friendly structure positioning categorized technical competencies immediately beneath the summary.",
        layout_family="ats-clean",
        thumbnail_accent="#1E40AF",
        recommended_for="Tech candidates seeking maximum keyword recognition on automated screeners."
    ),
    TemplateInfo(
        id="experience-focused",
        name="Experience-Focused",
        category="ATS-Friendly",
        description="Linear format prioritizing career trajectory, quantifiable achievements, and demonstrated industry scope.",
        layout_family="ats-clean",
        thumbnail_accent="#047857",
        recommended_for="Experienced professionals aiming for seamless screening at large organizations."
    ),
]

CATEGORIES = [
    "All",
    "Professional",
    "Technology",
    "Student and Fresher",
    "Creative",
    "ATS-Friendly"
]

def get_all_templates() -> List[TemplateInfo]:
    return TEMPLATES

def get_template_by_id(template_id: str) -> Optional[TemplateInfo]:
    for t in TEMPLATES:
        if t.id == template_id:
            return t
    return None
