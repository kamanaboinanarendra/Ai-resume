import os
import json
import logging
from typing import List, Dict, Any, Optional
from google import genai
from google.genai import errors
from app.core.config import settings

logger = logging.getLogger(__name__)

class GeminiServiceError(Exception):
    """Base exception for Gemini service errors."""
    pass

class GeminiNotConfiguredError(GeminiServiceError):
    """Raised when GEMINI_API_KEY is not set."""
    pass

class GeminiService:
    def __init__(self):
        self._client: Optional[genai.Client] = None

    def _get_client(self) -> genai.Client:
        key = settings.GEMINI_API_KEY or os.environ.get("GEMINI_API_KEY", "")
        if not key or not key.strip():
            raise GeminiNotConfiguredError(
                "Gemini API key is not configured on the server. Please set GEMINI_API_KEY in the backend .env file to enable AI assistance."
            )
        if self._client is None:
            self._client = genai.Client(api_key=key.strip())
        return self._client

    def is_configured(self) -> bool:
        key = settings.GEMINI_API_KEY or os.environ.get("GEMINI_API_KEY", "")
        return bool(key and key.strip())

    def get_model(self) -> str:
        model = settings.GEMINI_MODEL or os.environ.get("GEMINI_MODEL", "")
        return model.strip() if model.strip() else "gemini-3.8-flash"

    async def generate_chat_response(
        self,
        message: str,
        history: Optional[List[Dict[str, str]]] = None,
        section_context: Optional[str] = None,
        current_text: Optional[str] = None,
        resume_context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Generates context-aware conversational assistant reply and optional actionable suggestion.
        """
        client = self._get_client()
        model_name = self.get_model()

        system_prompt = (
            "You are the AI Assistant for the AI-Powered Resume Builder application. "
            "Your mission is to help users craft exceptional, ATS-optimized, honest, and impactful resumes. "
            "Guidelines:\n"
            "- Never fabricate credentials, employment history, degrees, awards, or fake metrics.\n"
            "- If the user asks for resume improvements or rewrites, preserve their factual truth while enhancing clarity, strong action verbs, and readability.\n"
            "- When proposing a direct replacement or improvement for a specific resume section (such as a professional summary or bullet point), provide a clear explanation and format the suggested text so it can be easily copied or applied.\n"
            "- Maintain an encouraging, professional, and concise tone.\n"
        )

        context_details = []
        if section_context:
            context_details.append(f"Current Resume Section: {section_context}")
        if current_text:
            context_details.append(f"Current Text in Section:\n\"\"\"{current_text}\"\"\"")
        if resume_context:
            title = resume_context.get("title", "")
            target_role = resume_context.get("personal_info", {}).get("professional_title", "")
            if target_role:
                context_details.append(f"Target Professional Title: {target_role}")

        full_prompt = system_prompt
        if context_details:
            full_prompt += "\n\nACTIVE RESUME CONTEXT:\n" + "\n".join(context_details) + "\n"

        if history:
            full_prompt += "\nCONVERSATION HISTORY:\n"
            for turn in history[-6:]: # keep recent turns
                role = "User" if turn.get("role") == "user" else "Assistant"
                full_prompt += f"{role}: {turn.get('content', '')}\n"

        full_prompt += f"\nUser Question: {message}\nAssistant:"

        try:
            response = client.models.generate_content(
                model=model_name,
                contents=full_prompt
            )
            reply_text = response.text or "I reviewed your request, but could not produce a response at this time."
            
            # Extract possible standalone suggestion if user asked for improvement
            suggestion = None
            if section_context and current_text and ("improve" in message.lower() or "rewrite" in message.lower() or "generate" in message.lower()):
                suggestion = reply_text.strip()

            return {
                "reply": reply_text,
                "suggestion": suggestion,
                "section_context": section_context
            }
        except errors.APIError as e:
            logger.error(f"Gemini API error: {e}")
            raise GeminiServiceError(f"Google Gemini API error: {str(e)}")
        except Exception as e:
            logger.error(f"Unexpected error calling Gemini: {e}")
            raise GeminiServiceError(f"Failed to communicate with Google Gemini: {str(e)}")

    async def improve_summary(
        self,
        text: str,
        role: Optional[str] = "",
        skills: Optional[List[str]] = None,
        action: str = "improve"
    ) -> str:
        """Improve or generate professional summary."""
        client = self._get_client()
        model_name = self.get_model()

        skills_str = ", ".join(skills) if skills else "relevant industry skills"
        
        if action == "generate" or not text.strip():
            prompt = (
                f"Write a concise, compelling, 3-4 sentence professional resume summary for a {role or 'professional'}. "
                f"Highlight core competencies including {skills_str}. "
                f"Do not invent specific past company names or unverified metrics. Keep it impactful, ATS-friendly, and ready to use."
            )
        else:
            prompt = (
                f"Improve the following professional summary for a {role or 'professional'} with skills ({skills_str}):\n\n"
                f"Original Summary:\n\"{text}\"\n\n"
                f"Requirements:\n"
                f"- Enhance professional vocabulary and impact with strong phrasing.\n"
                f"- Keep factual claims intact; do not fabricate awards or experience.\n"
                f"- Ensure it is concise (under 80 words), ATS-optimized, and impactful.\n"
                f"- Output ONLY the revised summary text without conversational preamble."
            )

        try:
            response = client.models.generate_content(
                model=model_name,
                contents=prompt
            )
            return (response.text or text).strip().strip('"')
        except errors.APIError as e:
            raise GeminiServiceError(f"Gemini API error: {str(e)}")
        except Exception as e:
            raise GeminiServiceError(f"AI improvement failed: {str(e)}")

    async def improve_description(
        self,
        text: str,
        role_or_project: Optional[str] = "",
        section_type: str = "experience",
        action: str = "improve"
    ) -> str:
        """Improve experience or project bullet points / responsibilities."""
        client = self._get_client()
        model_name = self.get_model()

        prompt = (
            f"You are an expert resume editor. Rewrite and elevate the following {section_type} description "
            f"for '{role_or_project or 'the role'}':\n\n"
            f"Original Content:\n\"{text}\"\n\n"
            f"Rules:\n"
            f"- Use strong action verbs at the beginning of bullet points (e.g., Developed, Engineered, Accelerated, Spearheaded).\n"
            f"- Preserve factual honesty; do NOT fabricate percentages, revenue numbers, or team sizes unless originally provided.\n"
            f"- Emphasize clarity, technical skill utilization, and tangible outcomes.\n"
            f"- Output the revised bullet points or paragraph directly, with no conversational preamble."
        )

        try:
            response = client.models.generate_content(
                model=model_name,
                contents=prompt
            )
            return (response.text or text).strip().strip('"')
        except errors.APIError as e:
            raise GeminiServiceError(f"Gemini API error: {str(e)}")
        except Exception as e:
            raise GeminiServiceError(f"AI description improvement failed: {str(e)}")

    async def suggest_skills(
        self,
        job_title: str,
        current_skills: List[str]
    ) -> List[str]:
        """Suggest industry-relevant skills for a target job title."""
        client = self._get_client()
        model_name = self.get_model()

        current_skills_str = ", ".join(current_skills) if current_skills else "none specified"
        prompt = (
            f"Given the target job title '{job_title}', suggest 10-15 highly sought-after, industry-standard technical and professional skills. "
            f"Current candidate skills already listed: {current_skills_str}.\n"
            f"Respond ONLY with a valid JSON array of skill name strings. Example format: [\"Skill A\", \"Skill B\"]."
        )

        try:
            response = client.models.generate_content(
                model=model_name,
                contents=prompt
            )
            raw = (response.text or "").strip()
            if raw.startswith("```json"):
                raw = raw[7:]
            if raw.startswith("```"):
                raw = raw[3:]
            if raw.endswith("```"):
                raw = raw[:-3]
            parsed = json.loads(raw.strip())
            if isinstance(parsed, list):
                return [str(s).strip() for s in parsed if s]
            return []
        except Exception as e:
            logger.warning(f"Could not parse Gemini skills suggestion: {e}")
            raise GeminiServiceError(f"Failed to generate skills suggestions: {str(e)}")

    async def analyze_job_match(
        self,
        job_description: str,
        resume_summary_text: str
    ) -> Dict[str, Any]:
        """Uses Gemini to identify semantic match highlights and actionable suggestions."""
        client = self._get_client()
        model_name = self.get_model()

        prompt = (
            f"Analyze the alignment between this Job Description and Candidate Resume.\n\n"
            f"JOB DESCRIPTION:\n\"\"\"{job_description[:3000]}\"\"\"\n\n"
            f"CANDIDATE RESUME SUMMARY:\n\"\"\"{resume_summary_text[:3000]}\"\"\"\n\n"
            f"Provide a structured JSON response with:\n"
            f"1. 'highlights': array of 2-3 specific strengths where candidate experience aligns with the JD.\n"
            f"2. 'actionable_tips': array of 3-4 concrete tips to tailor this resume honestly for this specific role.\n"
            f"Format as strict JSON: {{\"highlights\": [...], \"actionable_tips\": [...]}}"
        )

        try:
            response = client.models.generate_content(
                model=model_name,
                contents=prompt
            )
            raw = (response.text or "").strip()
            if raw.startswith("```json"):
                raw = raw[7:]
            if raw.startswith("```"):
                raw = raw[3:]
            if raw.endswith("```"):
                raw = raw[:-3]
            return json.loads(raw.strip())
        except Exception as e:
            logger.warning(f"Gemini job match analysis parsing fallback: {e}")
            return {
                "highlights": ["Relevant foundational skills match target job requirements."],
                "actionable_tips": [
                    "Align project descriptions with the exact technologies mentioned in the job description.",
                    "Ensure technical skills section highlights tools specified in the requirements.",
                    "Highlight quantifiable outcomes where applicable."
                ]
            }

gemini_service = GeminiService()
